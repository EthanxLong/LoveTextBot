import random

iLoveYou = ['I love youuu', 'Ana behibek', 'Yes kez sirumen', 'M’bi fe', 'Aamee tuma ke bhalo aashi', 'Ya tabe kahayu',
            'Nahigugma ako kanimo', 'Obicham te', 'Soro lahn nhee ah', 'Ngo oiy ney a', 'T’estimo',
            'Ne mohotatse', 'Ndimakukonda', 'Ti tengu caru', 'Mi aime jou', 'Volim te', 'Miluji te',
            'Jeg Elsker Dig', 'Ik hou van jou', 'Mi amas vin', 'Ma armastan sind', 'Afgreki’', 'Eg elski teg',
            'Doset daram', 'Mahal kita', 'Mina rakastan sinua', 'Je t’aime, Je t’adore', 'Ta gra agam ort',
            'Mikvarhar', 'Ich liebe dich', 'S’agapo', 'Hoo thunay prem karoo choo', 'Palangga ko ikaw',
            'Aloha wau ia oi', 'Ani ohev otah', 'Guina higugma ko ikaw', 'Hum Tumhe Pyar Karte hae',
            'Kuv hlub koj', 'Nu’ umi unangwa’ta', 'Szeretlek', 'Eg elska tig', 'Palangga ko ikaw', 'Saya cinta padamu',
            'Negligevapse', 'Taim i’ ngra leat', 'Ti amo', 'Aishiteru', 'Naanu ninna preetisuttene', 'Kaluguran daka',
            'Nakupenda', 'Tu magel moga cho', 'Sarang Heyo', 'Te amo', 'Es tevi miilu', 'Bahibak', 'Tave myliu',
            'Saya cintakan mu', 'Njan Ninne Premikunnu', 'Wo ai ni', 'Me tula prem karto', 'Kanbhik', 'Ana moajaba bik',
            'Ni mits neki', 'Ayor anosh’ni', 'Jeg Elsker Deg', 'Syota na kita!!', 'Inaru Taka', 'Mi ta stimabo',
            'Doo-set daaram', 'Iay ovlay ouyay', 'Kocham Ciebie', 'Eu te amo', 'Te ubesk', 'Ya tebya liubliu',
            'Tha gradh agam ort', 'Volim te', 'Ke a go rata', ',\\,,/ (ASL)', 'Maa tokhe pyar kendo ahyan',
            'Techihhila', 'Lu`bim ta', 'Ljubim te', 'Te quiero muchisimo', 'Ninapenda wewe', 'Jag alskar dig',
            'Ich lieb Di', 'Mahal kita', 'Wa ga ei li', 'Ua Here Vau Ia Oe', 'Nan unnai kathalikaraen',
            'Nenu ninnu premistunnanu', 'Phom rak khun', 'Seni Seviyorum', 'Ya tebe kahayu',
            'mai aap say pyaar karta hoo', 'Anh ye^u em ', '‘Rwy’n dy garu', 'Ikh hob dikh']

nickNames = ['bebe', 'cutie', 'lovely', 'Lelly', 'sexy', 'gorgeous', 'cuteness', 'bebecita', 'lubby',
              'love']

hi = ['Hewoo', 'Goodmorninggg', 'Hieeee', 'Heyy', 'Holaaaa']

emj = ['☺', '😍', '😘', '😚', '🥰', '🥺', '😻', '😽', '💋', '💖', '❤', '💕', '💗']

emj1 = (random.choice(emj))
emj2 = (random.choice(emj))
emj3 = (random.choice(emj))
emj4 = (random.choice(emj))
emj5 = (random.choice(emj))

greeting = (random.choice(hi))
ily = (random.choice(iLoveYou))
lelly = (random.choice(nickNames))
